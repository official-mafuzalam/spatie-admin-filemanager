
@include('layouts.public.header')

<main>
@yield('main_contant')
</main>

@include('layouts.public.footer')